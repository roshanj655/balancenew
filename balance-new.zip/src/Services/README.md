This directory contains application services, for example services to connect the application to APIs.
