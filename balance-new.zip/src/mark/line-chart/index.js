import LineChart from "./line-chart";

export default LineChart;
