This directory contains the base for the application styles.
