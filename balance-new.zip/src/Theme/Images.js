/**
 * Images should be stored in the `App/Images` directory and referenced using variables defined here.
 */

export default {
  //abc: require("../Assets/Images/")
  balance: require('../Assets/Images/balance2.png'),
  mind: require('../Assets/Images/mindIcon.png'),
  balanceTab: require('../Assets/Images/balanceTab.png'),
}
