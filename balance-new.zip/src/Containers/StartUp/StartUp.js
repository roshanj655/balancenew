function StartUp(){

    console.log("Inside StartUp");

    function checkIfLoggedInAlready(){
      
        
    }

    function logIn(){

    }
    
    return(
        logIn()
    )   
}

export default StartUp